#!/usr/bin/env python
import cv2
import numpy as np
import rospy
from std_msgs.msg import Int16

if __name__ == '__main__':
    lowerBound=np.array([0,221,134])
    upperBound=np.array([26,255,255])

    cam= cv2.VideoCapture(0)
    kernelOpen=np.ones((5,5))
    kernelClose=np.ones((20,20))

    pubx = rospy.Publisher('camera_posX', Int16, queue_size=10)
    puby = rospy.Publisher('camera_posY', Int16, queue_size=10)
    rospy.init_node('camera_robot')
    x_coordinate = Int16
    y_coordinate = Int16
    while True:
        ret, img=cam.read()
        #img=cv2.resize(img,(340,220))
        img=cv2.resize(img,(480,360))

        #convert BGR to HSV
        imgHSV= cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
        # create the Mask
        mask=cv2.inRange(imgHSV,lowerBound,upperBound)
        #morphology
        maskOpen=cv2.morphologyEx(mask,cv2.MORPH_OPEN,kernelOpen)
        maskClose=cv2.morphologyEx(maskOpen,cv2.MORPH_CLOSE,kernelClose)

        maskFinal=maskClose
        (_,conts,_)=cv2.findContours(maskFinal.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    
        cv2.drawContours(img,conts,-1,(255,0,0),3)
        for i in range(len(conts)):
            (x,y),radius = cv2.minEnclosingCircle(conts[i])
            center = (int(x),int(y))
            radius = int(radius)
            bola = cv2.circle(img,center,radius,(0,0,255),2)
            M = cv2.moments(conts[i])
            x = int(M['m10']/M['m00'])
            y = int(M['m01']/M['m00'])
            x_coordinate = x
            y_coordinate = y
            pubx.publish(x_coordinate)
            puby.publish(y_coordinate)
        cv2.imshow("maskClose",maskClose)
        #cv2.imshow("maskOpen",maskOpen)
        #cv2.imshow("mask",mask)
        cv2.imshow("cam",img)
        cv2.waitKey(10)
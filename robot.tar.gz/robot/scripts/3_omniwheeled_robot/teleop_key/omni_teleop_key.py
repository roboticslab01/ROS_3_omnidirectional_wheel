#!/usr/bin/env python

from __future__ import print_function

import roslib; roslib.load_manifest('teleop_twist_keyboard')
import rospy

#from geometry_msgs.msg import Twist
from std_msgs.msg import Int16
from std_msgs.msg import String

import sys, select, termios, tty

msg = """
Reading from the keyboard  and Publishing to Twist!
---------------------------
Moving around:
	q  w  e
	a  s  d 
	z  x  c
A = rotate left
D = rotate right
v = increase pwm_value by 5
b = decrease pwm_value by 5

anything else : stop

CTRL-C to quit
"""

moveBindings = {
		'q':(1,1,0), #x,y,th
		'w':(1,0,0), 
		'e':(1,-1,0),
		'a':(0,1,0),
		's':(0,0,0),
		'd':(0,-1,0),
		'z':(-1,1,0),
		'x':(-1,0,0),
		'c':(-1,-1,0),
		'A':(0,0,1),
		'D':(0,0,-1),
		}

pwmBindings = {
		'v':(-5),
		'b':(5),
		}

def getKey():
	tty.setraw(sys.stdin.fileno())
	select.select([sys.stdin], [], [], 0)
	key = sys.stdin.read(1)
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key

if __name__=="__main__":
    	settings = termios.tcgetattr(sys.stdin)
	
	#pub = rospy.Publisher('teleop_key', Twist, queue_size = 1)
	pub = rospy.Publisher('movement', String, queue_size=10)
	pub1= rospy.Publisher('pwm_value', Int16, queue_size = 10)
	rospy.init_node('omnirobot_teleop')


	pwm_send = Int16
	pwm_value = rospy.get_param("~pwm_value", 100)
	x=0;y=0;z=0
	#pwm_value = 100
	status = 0

	try:
		print(msg)
		rospy.loginfo("pwm value : %d", pwm_value)
		while(1):
			key = getKey()
			if key in moveBindings.keys():
				x = moveBindings[key][0]
				y = moveBindings[key][1]
				z = moveBindings[key][2]
				if(x>0)&(y==0)&(z==0):
					com = "f"
					#rospy.loginfo("forward")
				elif(x<0)&(y==0)&(z==0):
					com = "b"
					#rospy.loginfo("backward")
				elif(x==0)&(y>0)&(z==0):
					com = "l"
					#rospy.loginfo("left")
				elif(x==0)&(y<0)&(z==0):
					com = "r"
					#rospy.loginfo("right")
				elif(x>0)&(y>0)&(z==0):
					com = "q"
					#rospy.loginfo("left-forward")
				elif(x>0)&(y<0)&(z==0):
					com = "e"
					#rospy.loginfo("right-forward")
				elif(x<0)&(y>0)&(z==0):
					com = "z"
					#rospy.loginfo("left-backward")
				elif(x<0)&(y<0)&(z==0):
					com = "c"
					#rospy.loginfo("right-backward")
				elif(x==0)&(y==0)&(z>0):
					com = "p"
					#rospy.loginfo("rotate left")
				elif(x==0)&(y==0)&(z<0):
					com = "o"
					#rospy.loginfo("rotate right")
				elif(x==0)&(y==0)&(z==0):
					com = "s"
					#rospy.loginfo("stop")
				else:
					com = "s"
					#rospy.loginfo("stop")
				pub.publish(com)
			elif key in pwmBindings.keys():
				pwm_value = pwm_value + pwmBindings[key]
				if(pwm_value<0):
					pwm_value = 0
				elif(pwm_value>1020):
					pwm_value = 1020
				rospy.loginfo("pwm value : %d", pwm_value)
			else:
				x = x
				if (key == '\x03'):
					break
			pwm_send = pwm_value
			pub1.publish(pwm_send)			

	except Exception as e:
		print(e)

	finally:
		pub.publish(x)

    		termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)



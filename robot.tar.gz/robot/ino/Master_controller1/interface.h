#ifndef INTERFACE_H
#define INTERFACE_H

void menu_stanby();

#endif
